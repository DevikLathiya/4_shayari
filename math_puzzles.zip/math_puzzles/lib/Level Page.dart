import 'package:flutter/material.dart';
import 'package:math_puzzles/Config.dart';
import 'package:math_puzzles/Dashbord.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LevelPage extends StatefulWidget {
  const LevelPage({Key? key}) : super(key: key);

  @override
  State<LevelPage> createState() => _LevelPageState();
}

class _LevelPageState extends State<LevelPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(height: double.infinity,width: double.infinity,
         decoration: BoxDecoration(image: DecorationImage(fit: BoxFit.fill,image: AssetImage("image/background.jpg"))),
        child:Column(
          children: [
            Expanded(
              child: Container(height: double.infinity,width: double.infinity,alignment: Alignment.center,
                child:Text("Select Puzzle",style: TextStyle(fontSize: 35,fontWeight: FontWeight.bold),),
              ),
            ),
              Expanded(
                flex: 5,
                child: GridView.builder(
                  itemCount: level_img.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4),
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {

                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return Dashbord();
                        },));
                      },
                      child: Container(
                          margin: EdgeInsets.all(5),
                          alignment: Alignment.center,
                          child: Text("${levels[index]}"),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.black),
                              borderRadius: BorderRadius.circular(10),
                              //image: DecorationImage(image: (lock[cur_level] == true) ? AssetImage("image/tick.png") : AssetImage("image/tick.png"))
                          )),
                    );
                  },
                ),
              ),
              Expanded(flex: 0,
              child: IconButton(onPressed: () {
                print("next");
              }, icon: Image(image: AssetImage("image/next.png"),)),
            )
          ],
        )
      ),
    );
  }
}
