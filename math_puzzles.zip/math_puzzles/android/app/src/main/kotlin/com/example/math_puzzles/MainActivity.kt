package com.example.math_puzzles

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
